package edu.byu.cs.superasteroids.interfaces;

public interface IMainMenuView extends IView{
    /**
     * Instructs the ShipBuildingView to start the game.
     */
    void startGame();
}
