package edu.byu.cs.superasteroids.main_menu;

import edu.byu.cs.superasteroids.interfaces.IController;
import edu.byu.cs.superasteroids.interfaces.IMainMenuView;

/**
 * Created by audakel on 5/14/16.
 */
public class MainMenuView implements IMainMenuView {
    @Override
    public void startGame() {

    }

    @Override
    public IController getController() {
        return null;
    }

    @Override
    public void setController(IController controller) {

    }
}
