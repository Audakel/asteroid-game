package edu.byu.cs.superasteroids.base;

import edu.byu.cs.superasteroids.interfaces.IController;
import edu.byu.cs.superasteroids.interfaces.IView;

/**
 * Created by audakel on 5/16/16.
 */
public class View implements IView {
    @Override
    public IController getController() {
        return null;
    }

    @Override
    public void setController(IController controller) {

    }
}
